class Profiles::ApplicationController < ApplicationController
  layout 'profile'
end
