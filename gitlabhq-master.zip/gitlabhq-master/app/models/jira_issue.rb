class JiraIssue < ExternalIssue
end
