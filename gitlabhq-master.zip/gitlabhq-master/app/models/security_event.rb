class SecurityEvent < AuditEvent
end
