class PersonalSnippet < Snippet
end
