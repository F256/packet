# encoding: utf-8
require "logstash/filters/base"
require "logstash/namespace"

class LogStash::Filters::Example < LogStash::Filters::Base
  config_name "example"
  config :name,:validate =>:string,:default =>"xingoo!"

  public
  def register
  end

  public
  def filter(event)
    event["name"] = @name
    filter_matched(event)
  end
end
